<?php
  
namespace App\Http\Controllers\Front;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Session;
use App\Models\User;
use App\Models\Category;
use App\Models\Subcategory;

use Hash;
use DB;
class Frontcontroller extends Controller
    {
    
     public function index()
          {
      $categories = Category::where('status','selected')->get();
    
        return view ('front.home',compact('categories'));


    }
    public function index2()
    {
      
    }
   

  }