<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Category;
use App\Models\Subcategory ;
use Illuminate\View\View;
use App\Models\TempImage;   
use Image;
use DB;



class Categorycontroller extends Controller
{
        

    public function index(Request $request )
        {
            $categories = Category::get();
        //     if(!empty($request->get('keyword'))){
        //     $categories = $categories->where('name','like','%'.$request->get('keyword').'%'); 
        // //    }
        //     dd($categories);
            return view('admin.category.index', compact('categories'));
        }

    public function create()
    {
        return view ('admin.category.create');
    }

           public function  store(Request $request){

        
            request() ->validate([
                'name' =>'required|unique:categories',
                'slug' =>'required',
              
                'meta_title' =>'required' ,
                'image'=> 'mimes:jpeg,jpg,png,gif|max:1000' 

                
         
               ]); 
          
          $category = new Category;
           $category->name = ($request->name);
           $category->slug = ($request->slug);
         
           $category->meta_title = ($request->meta_title);
           $category->meta_description = ($request->meta_description);
           $category->meta_keywords = ($request->meta_keywords);
           $category->status = ($request->status);
           $category->showhome = ($request->showhome);

           if ($image = $request->file('image'))
           {
           $destinationPath = 'images/';
           $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
           $image->move($destinationPath, $profileImage);
           $category['image'] = "$profileImage";
           }
          
        //    $category->created_by = Auth::user()->id;
          $category->save();
 
        //   dd($request->all());
           
        return redirect('admin/categories/index')->with('success','Category has been created successfully.');
        }


        public function show(string $id): View
        {
            $category = Category::find($id);    //SELECT QUERY
            return view('admin.category.show',compact('category'));
        }
        
        public function edit(string $id): View
        {
            $category = Category::find($id);   //SELECT QUERY
            return view('admin.category.edit',compact('category'));
        }
        
        
        public function update(Request $request,$id)
        {
           
            request() ->validate([
                'name' =>'required|unique:categories',
                'slug' =>'required',
              
                'meta_title' =>'required'   

                
         
               ]); 
        $category =  Category::find($id);
        $category->name = ($request->name);
        $category->slug = ($request->slug);

        $category->meta_title = ($request->meta_title);
        $category->meta_description = ($request->meta_description);
        $category->meta_keywords = ($request->meta_keywords);
        $category->status = ($request->status);
        $category->showhome = ($request->showhome);

        if ($image = $request->file('image')) {
            $destinationPath = 'images/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $category['image'] = "$profileImage";
        }else{
            unset($category['image']);
        }
        $category->save();
        return redirect('admin/categories/index')->with('success','Category has been updated successfully.');

        }


  public function delete($id): RedirectResponse
        {
            $category = Category::find($id);  //SELECT QUERY 
            $category->delete();
          
         
            return redirect('admin/categories/index')->with(['success'=> 'Successfully deleted!!']);
            

        }
        




   public function changeStatus(Request $request) {

    $data = $request->all();

    $Cat = Category::find($data['id']);

    if ($Cat->status) {
        $Cat->status = 0;
    } else {
        $Cat->status = 1;
    }

    $Cat->save();

    $array = array();
    $array['status'] = $Cat->status;
    $array['success'] = true;
    $array['message'] = 'Status changed successfully!';
    echo json_encode($array);
}



}












































//     public function index(Request $request)
//     { 
//         $categories = Category::latest();

//         if(!empty($request->get('keyword'))){
//             $categories = $categories->where('name','like','%'.$request->get('keyword').'%'); 
//         }
//         $categories = $categories->paginate(50);
//         return view('admin.category.index',compact('categories'));
//     }

// //     public function check_slug(Request $request)
// // {
// //     $slug = str_slug($request->title);
// //     return response()->json(['slug' => $slug]);
// // }

//     public function create()
//     {
//         return view('admin.category.create');
//     }




//     public function store(Request $request)
// {
//     $validator = $this->validate($request, [
//         'name'         => 'required|min:3|max:255',
//         'slug'          => 'required|min:3|max:255|unique:categories',
//         'status'   => 'required|min:3'
//     ]);



    // public function store(Request $request)
    // {
    //     $validator = Validator::make($request->all(),[
    //         'name' =>'required',
    //         'slug' => 'required|unique:categories',

    //     ]);
    //     if($validator ->passes()){

    //         $category =new Category();
    //         $category ->name = $request->name;
    //         $category->slug = $request->slug;
    //         $category->status =$request->status;
    //         $category->save();     
            
            

    //     }
    // }


    // public function store(Request $request)
    // {
    //     $validator = $this->validate($request, [
    //         'title'         => 'required|min:3|max:255',
    //         'slug'          => 'required|min:3|max:255|unique:posts',
    //         'description'   => 'required|min:3'
    //     ]);
    
    //    


 
                //         //save image herepublic/uploads
                // if(!empty($request->image_id)){ 
                //     $tempImage = TempImage::find($request->image_id);
                //     // dd('$tempImage');
                //     $extArray = explode('.',$tempImage->name);
                //     $ext = last($extArray);
                //          //  dd('$ext');
                //     $newImageName = $category ->id.'.'.$ext;    //new image name 2.jpge
                //          $spath = public_path().'/images/'.$tempImage->name;     //source path
                //          $dpath = public_path().'/uploads/category/'.$newImageName;      //destination path

                //     File::copy($spath,$dpath);

                    // //generate Image Thumbnail
                    // $dpath = storage_path().'/category/'.$newImageName;  
                    // $img =Image::make($spath);
                    // $img->resize(450,600);
                    // $image->save($dpath);

    //                 $category->image = $newImageName;   //save new image in category folder
    //                 $category->save();
    //             }

    //         $request->session()->flash('success','Category added successfully');

    //         return response()->json([
    //             'status' => true,
    //             'message' =>'Category added successfully'
    //         ]);


    //     }else{
    //        return response()->json([
    //         'status' => false,
    //         'errors' =>$validator->errors()
    //        ]);
    //     }
    // }




    // https://blog.codehunger.in/create-dynamic-categories-and-subcategories-in-laravel-7-8/
    // https://www.youtube.com/watch?v=hezUY9BCb7c&list=PL_99hMDlL4d3-n63bsNaaDRnTZdCOvU6q&index=29 without package

    // https://www.youtube.com/watch?v=6x       JQflhWvU0&list=PLs20WIPqzFC7Bj39TrJ82EFvF0reuB5hz&index=17
    // https://www.youtube.com/watch?v=d8cPrEUlrgY&list=PLoBGtBK7uqyWu-c8WsJODaw_1vjCaysq-&index=11