<?php
  
namespace App\Http\Controllers\admin;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use Hash;
  
class Dashboardcontoller extends Controller
{
    public function index(){
        return view('admin.dashboard');
    //     $admin =Auth::guard('admin')->user();
    //    echo'wellcome' .$admin->name.'<a href="'.route('admin.logout').'">logout</a>';
    }



    public function page(){
        return view('admin.page');
  
    }

    public function createpage(){
        return view('admin.createpage');
    
    }

        public function logout()
        {
            Auth::guard('admin')->logout();
            Session::flush();
            Session::put('success', 'You are logout sucessfully');
            return redirect('admin/login');
        }
}