<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Subcategory;
use Illuminate\View\View;

use DB;



class BrandController extends Controller
{
    


    public function index(Request $request )
        {
            $brands = Brand::get();
        
            return view('admin.brand.index', compact('brands'));
        }

   
        public function create()
        {
            return view ('admin.brand.create');
        }
             

                    public function  store(Request $request)

                    {
                        $this->validate($request, [
                            'name' =>'required|unique:brands',
                            'slug' =>'required|',
                           
                            'meta_title' =>'required'


                      
                   
                           ]); 
                        
                        $brand = new Brand;
                        
                        $brand->name = ($request->name);
                        $brand->slug = ($request->slug);
                        $brand->status = ($request->status);
                        $brand->meta_title = ($request->meta_title);
                        $brand->meta_description = ($request->meta_description);
                        $brand->meta_keywords = ($request->meta_keywords);
                    //    $brand->created_by = Auth::user()->id;
                        $brand->save();
                
                    //   dd($request->all());
                        
                    return redirect('admin/brand/index')->with('success','Category has been created successfully.');
                    }


                    public function edit(string $id): View
                    {
                        $brand = Brand::find($id);   //SELECT QUERY
                        return view('admin.brand.edit',compact('brand'));
                    }
                    
            

                     
        public function update(Request $request,$id)
        {
           
            request() ->validate([
                'name' =>'required|unique:brands',
                'slug' =>'required',
              
                'meta_title' =>'required'   

                
         
               ]); 
        $brand =  Brand::find($id);
        $brand->name = ($request->name);
        $brand->slug = ($request->slug);
        $brand->status = ($request->status);
        $brand->meta_title = ($request->meta_title);
        $brand->meta_description = ($request->meta_description);
        $brand->meta_keywords = ($request->meta_keywords);
        $brand->save();
        return redirect('admin/brand/index')->with('success','brand has been updated successfully.');

        }



            public function delete($id): RedirectResponse
            {
                $brand = Brand::find($id);  //SELECT QUERY 
                $brand->delete();
                
            
                return redirect('admin/brand/index')->with(['success'=> 'Successfully deleted!!']);
                

            }




   public function changeStatus(Request $request) {

    $data = $request->all();

    $brandes = Brand::find($data['id']);

    if ($brandes->status) {
        $brandes->status = 0;
    } else {
        $brandes->status = 1;
    }

    $brandes->save();

    $array = array();
    $array['status'] = $brandes->status;
    $array['success'] = true;
    $array['message'] = 'Status changed successfully!';
    echo json_encode($array);
}


}

