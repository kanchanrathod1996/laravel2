<?php
  
namespace App\Http\Controllers\admin;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Session;
use App\Models\User;
use Hash;
use DB;
class Adminlogincontoller extends Controller
{
   
      public function index(){
            return view('admin.login');
        }
     
        public function authenticate(Request $request)
        {
            // dd($request->all());


            $request->validate([
                'email' => 'required|email',    
                'password' => 'required',
            ]);
                    //  if ($request->passes())
                    //  {
                        // dd('afa');
                if(Auth::guard('admin')->attempt(['email'=>$request->email,'password'=>$request->password]))
                                {
                                    
                                    // dd($request->all());
                                    return redirect()->route('admin.dashboard');
                                }else{

                                    return back()->with('error','Whoops! invalid email and password.');
                                }
                            
                    //  }
                    //  else{
                    //     return redirect()->route('admin.login')
                    //           ->withError($request)
                    //           ->withInput($request->only('email'));

                    //  }
     
        }
        // public function postLogin(Request $request)
        // {
        //     $this->validate($request, [
        //         'email' => 'required|email',
        //         'password' => 'required',
        //     ]);
     
        //     if(auth()->guard('admin')->attempt(['email' => $request->input('email'),  'password' => $request->input('password')])){
        //         $user = auth()->guard('admin')->user();
        //     //     if($user->role == 1){
        //             return redirect('/admin/dashboard')->with('success','You are Logged in sucessfully.');
        //     //     }
        //     }else {
        //         return back()->with('error','Whoops! invalid email and password.');
        //     }
        // }
     
        public function adminLogout(Request $request)
        {
            auth()->guard('admin')->logout();
            Session::flush();
            Session::put('success', 'You are logout sucessfully');
            return redirect('/login');
        }
    }









