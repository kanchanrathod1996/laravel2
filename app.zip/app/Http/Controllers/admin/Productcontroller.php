<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Models\Product;
use App\Models\Subcategory;
use App\Models\Brand;
use App\Models\Category;
// use Illuminate\View\View;

use DB;



class Productcontroller extends Controller
{

    public function index(){
      
        $products = Product::get();
        
        return view ('admin.product.index', compact('products'));
    }


    public function create()
    {
        
        $category = Category::get();
        $subcategory = Subcategory::get();
        $brand = Brand::get();
        return view ('admin.product.create',compact('category','subcategory','brand'));
    }
    

    public function  store(Request $request)
    {
        request() ->validate([
            'title' =>'required',
            'slug' =>'required',
            
            'price' =>'required',
            'shipping_returns' =>'required',
            'image'=> 'mimes:jpeg,jpg,png,gif|max:1000',
           ]); 
         

         $product = new Product;
         
          $product->title = ($request->title);
          $product->slug = ($request->slug);
          $product->category_id = ($request->category_id);
          $product->subcategory_id = ($request->subcategory_id);
          $product->brand_id = ($request->brand_id);
          $product->price = ($request->price);
        
          $product->description = ($request->	description);
          $product->shipping_returns = ($request->	shipping_returns);
    
     
           
     if ($image = $request->file('image'))
     {
     $destinationPath = 'images/';
     $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
     $image->move($destinationPath, $profileImage);
     $product['image'] = "$profileImage";
     }
         $product->save();

       //   dd($request->all());
          
       return redirect('admin/product/index')->with('success','product has been created successfully.');
       }

   

      public function getSubCat(Request $request)
      { 
        $cid = $request->cid;
        $subcategory = Subcategory::with('category')->where('category_id',$cid)->get();
        return response()->json($subcategory);

       }

}
