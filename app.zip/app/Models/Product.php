<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'id','title','image','slug','category_id','subcategory_id','brand_id','old_price','price','short_description',
        	'description','additional_information','shipping_returns','status'];

       
            // Product model

      public function categories() { 
               return $this->belongsTo(Category::Class,'category_id');
         }

      public function subcategories() {
               return $this->belongsTo(Subcategory::Class,'subcategory_id');
        }
        public function brands() {
            return $this->belongsTo(Brand::Class,'brand_id');
     }


}
