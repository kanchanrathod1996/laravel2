@extends('admin.layouts.app')
@section('content')





			<!-- Content Header (Page header) -->
            <section class="content-header">					
					<div class="container-fluid my-2">	
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1>Create Product</h1>
							</div>
							<div class="col-sm-6 text-right">
								<a href="{{route('product.index')}}" class="btn btn-primary">Back</a>
							</div>
						</div>
					</div>
					<!-- /.container-fluid -->
				</section>
				<!-- Main content -->
				<section class="content">
					<!-- Default box -->



	<div class="container-fluid">

					@if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
	<form action="{{route('product.store')}}" method="POST" id="categoryForm" name="categoryForm"  enctype="multipart/form-data">
		@csrf
	
					
					<div class="row">
						
                            <div class="col-md-8">
								
                                <div class="card mb-3">
                                    <div class="card-body">								
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="mb-3">
                                                    <label for="title">Title</label>
                                                    <input type="text" name="title" id="title" class="form-control" placeholder="Title">	
                                                </div>
                                            </div>

											<div class="col-md-12">
                                                <div class="mb-3">
												     <label for="price">Price</label>
											           <input type="number"   name="price" id="price" value ="{{old('price')}}" class="form-control" >	
										      </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="mb-3">
												<label for="description">Description</label>
											     <input type="text"   name="description" id="description" value ="{{old('description')}}" class="form-control" >	
										        </div>
                                            </div> 

											<div class="col-md-12">
                                                <div class="mb-3">
												<label for="shipping_returns">shipping_returns</label>
											     <input type="text"   name="shipping_returns" id="shipping_returns" value ="{{old('shipping_returns')}}" class="form-control" >	
										       </div>
                                            </div>

                                        </div>
                                    </div>	                                                                      
                                </div>

                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h2 class="h4 mb-3">Media</h2>								
										<div class="col-md-6">
										<div class="mb-3">
										
											<input type="file"   name="image" id="image" value ="{{old('image')}}" class="form-control" >	
										
										</div>
									</div>
                                    </div>	                                                                      
                                </div>


                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h2 class="h4 mb-3">Inventory</h2>								
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <label for="sku">Slug</label>
                                                    <input type="text" name="slug" id="slug" class="form-control" placeholder="Slug">	
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <label for="barcode">Barcode</label>
                                                    <input type="text" name="barcode" id="barcode" class="form-control" placeholder="Barcode">	
                                                </div>
                                            </div>   
                                            <div class="col-md-12">
                                                <div class="mb-3">
                                                    <div class="custom-control custom-checkbox">
                                                        <input class="custom-control-input" type="checkbox" id="track_qty" name="track_qty" checked>
                                                        <label for="track_qty" class="custom-control-label">Track Quantity</label>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="number" min="0" name="qty" id="qty" class="form-control" placeholder="Qty">	
                                                </div>
                                            </div>                                         
                                        </div>
                                    </div>	                                                                      
                                </div>
                            </div>







                            <div class="col-md-4">
                                <div class="card mb-3">
                                    <div class="card-body">	
                                        <h2 class="h4 mb-3">Product status</h2>
                                        <div class="mb-3">
                                        <select  class="form-control" name ="status" id="status">
                                                 <option {{(old('status')=='0')? 'selected' : ''}}  value="0">active</option>
                                                 <option  {{(old('status')=='1')? 'selected' : ''}} value="1">inactive</option>
                                            </select>
											
                                        </div>
                                    </div>
                                </div> 
                                <div class="card">
                                    <div class="card-body">	
                                        <h2 class="h4  mb-3">Product category</h2>
                                        <div class="mb-3">
											<label for="category">category</label>
											<select name="category_id" id="category" class="form-control" >
                                                <option value = "" >Select category</option>
                                             @foreach($category as $list)
											 
                                             <option value = "{{ $list->id }}" >{{$list->name}}</option>
                                             @endforeach
                                                </select>
									    </div>

										
                                        <div class="mb-3">
                                        <label class="mb-1">Select Subcategory</label>
    					             <select name="name" id="subcategory" class="form-control get_subcategory"></select>
									    </div>

                                    </div>
                                </div> 

                                <div class="card mb-3">
                                    <div class="card-body">	
                                        <h2 class="h4 mb-3">Product brand</h2>
                                        <div class="mb-3">
										
											<select name="brand_id" id="brand" class="form-control" >
                                       
                                             @foreach($brand as $v)
											 
                                             <option value = "{{ $v->id }}" >{{$v->name}}</option>
                                             @endforeach
                                                </select>
									    </div>

                                    </div>
                                
							    </div>  

                            </div>
                        </div>
						
						






						<div class="pb-5 pt-3">
							<button type="submit" class="btn btn-primary">Create</button>
							<a href="{{route('categories.index')}}" class="btn btn-outline-dark ml-3">Cancel</a>
						</div>
						
                        </form>
					</div>
			
				</section>
				
			

					
@endsection



@section('customjs')
		
				
 <script>
    
$(document).ready(function(){

$('#category').change(function(){
       let cid=$(this).val();   
       $.ajax({
           url:'{{ route("product.getSubCat") }}',
           type:'post',
           data:'cid='+cid+
			  '&_token={{csrf_token()}}',
            
           success:function(result){
            console.log(result);
            $('#subcategory').empty();
                $.each(result, function(key, value) {

                var id = value.id;
                var name = value.name;
                $('#subcategory').append('<option value="'+ id +'">'+ name +'</option>');
            });
           }

       });

  });
});
  
</script>
				
@endsection

