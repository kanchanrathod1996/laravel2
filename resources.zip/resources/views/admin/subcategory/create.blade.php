@extends('admin.layouts.app')
@section('content')





			<!-- Content Header (Page header) -->
            <section class="content-header">					
					<div class="container-fluid my-2">	
					
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1>Create Sub Category</h1>
							</div>
							<div class="col-sm-6 text-right">
								<a href="{{route('subcategories.index')}}" class="btn btn-primary">Back</a>
							</div>
						</div>
					</div>
					<!-- /.container-fluid -->
				</section>
				<!-- Main content -->
				<section class="content">
					<!-- Default box -->
					<div class="container-fluid">
					@if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                        <form action="{{route('subcategories.store')}}" method="POST" id="categoryForm" name="categoryForm" enctype="multipart/form-data">
						@csrf
						<div class="card">
							<div class="card-body">								
								<div class="row">
                                  <div class="col-md-6">
										<div class="mb-3">
											<label for="name">category</label>
											<select name="category_id" id="category" class="form-control" >
                                       
                                             @foreach($category as $v)
											 
                                             <option value = "{{ $v->id }}" >{{$v->name}}</option>
                                             @endforeach
                                                </select>
									    </div>
									</div>

									
                                    <div class="col-md-6">
										<div class="mb-3">
											<label for="name">Sub Category</label>
											<input type="text"   name="name" id="name" class="form-control" placeholder="name">	
											
										</div>
									</div>



									
									<div class="col-md-6">
										<div class="mb-3">
											<label for="slug">Slug</label>
											<input type="text"   name="slug" id="slug" value ="{{old('slug')}}" class="form-control" >	
										
										</div>
									</div>
                                    

                                    
	
									<div class="col-md-6">
										<div class="mb-3">
											<label for="title">Meta Title</label>
											<input type="text"   name="meta_title" id="meta_title" value ="{{old('meta_title')}}" class="form-control" >	
										
										</div>
									</div>
                                    
	
									<div class="col-md-6">
										<div class="mb-3">
											<label for="description">Meta Description</label>
										<textarea class="form-control" name="meta_description" id="meta_description" value ="{{old('meta_description')}}"  cols="10" rows="10"></textarea>
										</div>
									</div>
                                    
	
									<div class="col-md-6">
										<div class="mb-3">
											<label for="keyword">Meta keyword</label>
											<input type="text"   name="meta_keywords" id="meta_keywords" value ="{{old('meta_keyword')}}" class="form-control" >	
										
										</div>
									</div>
                                    




                       	             <div class="col-md-6">
										<div class="mb-3">
											<label for="status">Status</label>
                                            <select  class="form-control" name ="status" id="status">
                                                 <option {{(old('status')=='0')? 'selected' : ''}}  value="0">active</option>
                                                 <option  {{(old('status')=='1')? 'selected' : ''}} value="1">inactive</option>
                                            </select>
											
										</div>
									</div>	

									<div class="col-md-6">
										<div class="mb-3">
											<label for="status">show on Home</label>
                                            <select  class="form-control" name ="showhome" id="status">
                                                 <option  value="yes">yes</option>
                                                 <option  value="no">No</option>
                                            </select>
											
										</div>
									</div>	

								</div>
							</div>								
						</div>
                  
						<div class="pb-5 pt-3">
							<button type="submit" class="btn btn-primary">Create</button>
							<a href="{{route('subcategories.index')}}" class="btn btn-outline-dark ml-3">Cancel</a>
						</div>
						
                        </form>
					</div>
					<!-- /.card -->
				</section>
				
			
			
				
				

				
@endsection



