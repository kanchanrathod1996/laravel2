<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\admin\Adminlogincontoller;
use App\Http\Controllers\admin\Dashboardcontoller;
use App\Http\Controllers\admin\Categorycontroller;
use App\Http\Controllers\admin\TempImagecontroller;
use App\Http\Controllers\admin\Subcategorycontroller;
use App\Http\Controllers\admin\Productcontroller;
use App\Http\Controllers\admin\BrandController;
use App\Http\Controllers\admin\Usercontroller;
use App\Http\Controllers\Front\Frontcontroller;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// $password =  '123456';
// dd(bcrypt($password));

Route::get('/', [Frontcontroller::class, 'index'])->name('front.home');






            
Route::group(['prefix' => 'admin'],function(){
    route::group(['middleware' => 'admin.guest'],function(){
       
         Route::get('/login', [Adminlogincontoller::class, 'index'])->name('admin.Login');
         Route::post('/login', [Adminlogincontoller::class, 'authenticate'])->name('admin.authenticate');
    });

    route::group(['middleware' => 'admin.auth'],function(){

        Route::get('/dashboard', [Dashboardcontoller::class, 'index'])->name('admin.dashboard');
        Route::get('/logout', [Dashboardcontoller::class, 'logout'])->name('admin.logout');

        // category Routes
       
Route::get('categories/index',[Categorycontroller::class,'index'])->name('categories.index');
Route::get('categories/create',[Categorycontroller::class,'create'])->name('categories.create');
Route::any('categories/store',[Categorycontroller::class,'store'])->name('categories.store');
Route::get('categories/show/{id}',[Categorycontroller::class,'show'])->name('categories.show');
Route::get('categories/edit/{id}',[Categorycontroller::class,'edit'])->name('categories.edit');
Route::any('categories/update/{id}',[Categorycontroller::class,'update'])->name('categories.update');
Route::get('categories/delete/{id}',[Categorycontroller::class,'delete'])->name('categories.delete');
Route::post('categories/changeStatus', [Categorycontroller::class, 'changeStatus'])->name('categories.changeStatus');


Route::post('subcategories/changeStatus', [Subcategorycontroller::class, 'changeStatus'])->name('subcategories.changeStatus');
Route::get('subcategories/index',[Subcategorycontroller::class,'index'])->name('subcategories.index');
Route::get('subcategories/create',[Subcategorycontroller::class,'create'])->name('subcategories.create');
Route::any('subcategories/store',[Subcategorycontroller::class,'store'])->name('subcategories.store');
Route::get('subcategories/show/{id}',[Subcategorycontroller::class,'show'])->name('subcategories.show');
Route::get('subcategories/edit/{id}',[Subcategorycontroller::class,'edit'])->name('subcategories.edit');
Route::any('subcategories/update/{id}',[Subcategorycontroller::class,'update'])->name('subcategories.update');
Route::get('subcategories/delete/{id}',[Subcategorycontroller::class,'delete'])->name('subcategories.delete');



Route::get('product/index',[Productcontroller::class,'index'])->name('product.index');
Route::get('product/create',[Productcontroller::class,'create'])->name('product.create');
Route::any('product/store',[Productcontroller::class,'store'])->name('product.store');
Route::any('product/getSubCat',[Productcontroller::class,'getSubCat'])->name('product.getSubCat');


Route::get('brand/index',[BrandController::class,'index'])->name('brand.index');
Route::get('brand/create',[BrandController::class,'create'])->name('brand.create');
Route::any('brand/store',[BrandController::class,'store'])->name('brand.store');
Route::get('brand/show/{id}',[BrandController::class,'show'])->name('brand.show');
Route::get('brand/edit/{id}',[BrandController::class,'edit'])->name('brand.edit');
Route::any('brand/update/{id}',[BrandController::class,'update'])->name('brand.update');
Route::get('brand/delete/{id}',[BrandController::class,'delete'])->name('brand.delete');
Route::post('brand/changeStatus', [BrandController::class, 'changeStatus'])->name('brand.changeStatus');


Route::get('page',[Dashboardcontoller::class,'page'])->name('page');
Route::get('createpage',[Dashboardcontoller::class,'createpage'])->name('createpage');
Route::get('createbrand',[Categorycontroller::class,'createbrand'])->name('createbrand');



        // Route::get('/check_slug', [Categorycontroller::class, 'check_slug'])->name('pages.check_slug');

    });


});





